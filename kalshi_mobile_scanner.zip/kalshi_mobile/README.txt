KALSHI MOBILE SCANNER (free prototype)

This is a mobile-friendly, read-only web page. It fetches public Kalshi BTC 5M and 15M market snapshots. It is NOT an automated trading bot, not a validated predictive model, and it does not place trades.

ON IPHONE:
1. Upload index.html to a static website host that supports HTML files (e.g. Cloudflare Pages via a GitHub repository or direct upload).
2. Open the resulting HTTPS website in Safari.
3. Tap Share > Add to Home Screen.

Directly opening a local HTML file on iOS may prevent network requests. Even on a host, Kalshi's browser CORS policy may block requests. If that happens, a small server-side API proxy is required; do not place private API keys in browser code.

Market discovery depends on Kalshi's current series tickers. If Kalshi renames the 5-minute or 15-minute series, update the series list in index.html.

For actual trade signals, add BTC historical candles, market settlement-rule alignment, calibrated probability estimation, backtesting, transaction costs, and paper trading. Do not treat WATCH flags as profitable trades.
